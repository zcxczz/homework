#ifndef LIST_H_
#define LIST_H_// LI
#include<pthread.h>
typedef struct linktablenode
{
    struct linktablenode *next;
}tlinktablenode;

typedef struct linktable
{
    tlinktablenode *phead;
    tlinktablenode *ptail;
    int sumofnode;
    pthread_mutex_t mutex;
}tlinktable;

tlinktable * createlinktable();

int deletelinktable(tlinktable *plinktable);

int addlinktablenode(tlinktable *plinktable,tlinktablenode *pnode);

int dellinktablenode(tlinktable *plinktable,tlinktablenode *pnode);

tlinktablenode * getlinktablehead(tlinktable *plinktable);

tlinktablenode * getnextlinktablenode(tlinktable *plinktable,tlinktablenode *pnode);

#endif
